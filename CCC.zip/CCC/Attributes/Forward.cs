using UnityEngine;

public class ForwardAttribute : PropertyAttribute
{
    public ForwardAttribute() { }
}
