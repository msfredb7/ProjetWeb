﻿using UnityEngine;

//[System.Flags]
//public enum Hello
//{
//    A = 1 << 0,
//    B = 1 << 1,
//    C = 1 << 2,
//    All = A | B | C
//}

public class BitMaskAttribute : PropertyAttribute
{
    public BitMaskAttribute() { }
}