﻿
using UnityEditor;

[CustomPropertyDrawer(typeof(StringReference))]
public class StringReferenceDrawer : VarReferenceDrawer
{
}
