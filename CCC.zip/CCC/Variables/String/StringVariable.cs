﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Var_NewString", menuName = "CCC/Variable/String")]
public class StringVariable : VarVariable<string>
{
}
