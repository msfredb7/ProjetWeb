﻿using UnityEditor;

[CustomPropertyDrawer(typeof(IntReference))]
public class IntReferenceDrawer : VarReferenceDrawer
{
}
