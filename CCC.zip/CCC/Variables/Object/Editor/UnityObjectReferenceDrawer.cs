﻿using UnityEditor;

[CustomPropertyDrawer(typeof(UnityObjectReference))]
public class UnityObjectReferenceDrawer : VarReferenceDrawer
{
}
