﻿using UnityEngine;

[CreateAssetMenu(fileName ="Var_NewObject", menuName ="CCC/Variable/Object")]
public class UnityObjectVariable : VarVariable<Object>
{

}
