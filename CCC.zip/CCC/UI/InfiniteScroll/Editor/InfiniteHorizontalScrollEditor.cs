﻿using UnityEditor;

[CustomEditor(typeof(InfiniteHorizontalScroll))]
public class InfiniteHorizontalScrollEditor : InfiniteScrollEditor { }
