﻿using UnityEditor;


[CustomEditor(typeof(InfiniteVerticalScroll))]
public class InfiniteVerticalScrollEditor : InfiniteScrollEditor { }
