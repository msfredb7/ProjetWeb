﻿
using UnityEditor;

[CustomEditor(typeof(InfiniteGridScroll))]
public class InfiniteGridScrollEditor : InfiniteScrollEditor { }