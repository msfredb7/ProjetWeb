﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class DataSaverBank
{
    public enum Type
    {
        Account,
        Armory,
        Dialog,
        Levels,
        Loadout,
        Tutorial
    }
}
